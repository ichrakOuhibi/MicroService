package com.repository;

import com.entities.Article;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepoArticle extends MongoRepository<Article, Integer> {
}
