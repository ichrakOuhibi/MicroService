package com.entities;

import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;


@Document("Article")
@Getter
@Setter
public class Article {

    private Long idArticle;
    String Description;
    String Reference;

    public Article(Long idArticle, String description, String reference) {
        super();
        this.idArticle = idArticle;
        this.Description = description;
        this.Reference = reference;
    }
}