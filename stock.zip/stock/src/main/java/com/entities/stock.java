package com.entities;

import jakarta.persistence.*;
import lombok.*;

@Table(name = "Stock")
@Entity
@Getter
@Setter

public class stock {
    @Id
    @Column(name = "id_stock", nullable = false)
    long idStock;
    @Column(name ="nomProduit")
    String nomProduit;
    @Column(name ="numbrProduit")
    int numbrProduit;
    @Column(name ="categorie")
    String categorie;
}
