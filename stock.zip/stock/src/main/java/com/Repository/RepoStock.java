package com.Repository;

import com.entities.stock;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepoStock extends CrudRepository<stock, Integer> {
}
